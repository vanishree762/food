var PLAY = 1;

var END = 0;

var gameState = PLAY;

var sword,swordImage;

var gameoverImage, gameover;

var knifeSwooshSound,gameoverSound;

var score;

var fruit, fruit1,fruit2,fruit3,fruit4;

var fruitGroup, EnemyGroup;

var alien1,alien1Image, alien2, alien2Image;

var alien1Group;
var alien2Group;


function preload(){
 
  swordImage = loadImage("sword.png");
  knifeSwooshSound = loadSound("knifeSwooshSound.mp3")
  gameoverSound = loadSound("gameover.mp3")
  alien1Image = loadImage("alien1.png");
  alien2Image = loadImage("alien2.png");
  fruit1 = loadImage("fruit1.png");
  fruit2 = loadImage("fruit2.png");
  fruit3 = loadImage("fruit3.png");
  fruit4 = loadImage("fruit4.png");
  gameoverImage = loadImage("gameover.png");
  
}

function setup(){
  
  createCanvas(600,600);
  
  gameover = createSprite(270,100,250,10);
  gameover.addImage("gameover",gameoverImage);
  gameover.scale = 5;
  gameover.visible = false;

  sword = createSprite(40,200,20,20);
  sword.addImage(swordImage);
  sword.scale = 0.7;
  sword.setCollider("rectangle",10,20,100,90);
  sword.debug = false
  
   fruitGroup = createGroup();
   EnemyGroup = createGroup();
  
  alien1Group = new Group();
  alien2Group = new Group();
  
  score = 0;
  
 
}

function draw() {
  background("green");
  text("Score: "+ score, 500,50);
  
  if(gameState === PLAY){
  
    fruits();
    Enemy();
    
    if (keyDown("space")) {
    createsword();
  }
    
    
    sword.y = World.mouseY;
    sword.x = World.mouseX;
    
    
 if(fruitGroup.isTouching(sword)){
    fruitGroup.destroyEach(0);
   knifeSwooshSound.play();
    score = score + 2;
  }
    if(alien1Group.isTouching(sword)){
     
     gameoverSound.play();
      gameState = END;
    }
  
    if(alien2Group.isTouching(sword)){
     
     gameoverSound.play();
      gameState = END;
    }
    
   }
  
  else if (gameState === END) {
    
    sword.addImage(gameoverImage);
    sword.x = 200;
    sword.y = 200;

    sword.velocityX = 0;
    sword.velocityY = 0;

     fruitGroup.setVelocityXEach(0);
     alien1Group.setVelocityXEach(0);
    alien2Group.setVelocityXEach(0);
     
     //alien1Group.setLifetimeEach(-5);
     //fruitGroup.setLifetimeEach(-5);
    
    alien1Group.destroyEach(0);
    alien2Group.destroyEach(0);
     
  
   }

  drawSprites();
}

function fruits(){
 if (frameCount % 80 === 0){
    fruit = createSprite(600,200,20,20);
    fruit.scale = 0.2;
  var r = Math.round(random(1,4));
   if(r === 1){
     fruit.addImage(fruit1);
   } else if(r === 2){
     fruit.addImage(fruit2);
   } else if(r === 3){
   fruit.addImage(fruit3);
   } else if(r === 4) {
     fruit.addImage(fruit4);
   }

  
  fruit.y = Math.round(random(50,340));
    
  fruit.velocityX = -(7+(score/10));
  fruit.setLifetime = 100;
  
  fruitGroup.add(fruit);
}

}



function Enemy(){

  
 if (World.frameCount % 200 === 0){
   var alien1 = createSprite(600,200,10,20);
   alien1.addAnimation("moving",alien1Image);
   alien1.y = Math.round(random(100,300));
   alien1.velocityX = -(8+(score/10));
   alien1.setLifetime = 50;
   
   alien1Group.add(alien1);
    
 }
  if (World.frameCount % 200 === 0){
   var alien2 = createSprite(600,200,10,20);
   alien2.addAnimation("moving",alien2Image);
   alien2.y = Math.round(random(100,300));
   alien2.velocityX = -(8+(score/10));
   alien2.setLifetime = 50;
    alien2Group.add(alien2);
  }
  
  
  
  
}



